<?php get_header(); ?>
<?php
    global $wp_query; 
    $itemsFound = $wp_query->found_posts;
?>
<main>
  asdasd
</main>

<?php
get_footer();