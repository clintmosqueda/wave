<?php
add_theme_support('post-thumbnails');
add_image_size( 'card-work', 1110, 694, true );
add_image_size( 'card-project', 1406, 926, true );
add_image_size( 'card-news', 812, 508, true );
add_image_size( 'card-interview', 810, 480, true );
