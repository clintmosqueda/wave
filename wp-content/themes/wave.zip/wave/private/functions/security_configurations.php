<?php

remove_action('wp_head', 'wp_generator');
