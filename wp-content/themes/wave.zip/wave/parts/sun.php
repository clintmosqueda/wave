<?php
$modifier = empty($modifier) ? '' : $modifier;
$speed = empty($speed) ? '' : $speed;
?>

<div 
  class="sun <?php echo $modifier;?>" 
  data-rellax-speed="<?php echo $speed; ?>" 
  data-rellax-percentage="0.5">
</div>