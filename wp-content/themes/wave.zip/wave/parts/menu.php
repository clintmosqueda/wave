<div class="menu">
  <div class="menu-block">
    <span class="menu-dash"></span>
    <span class="menu-dash"></span>
    <span class="menu-dash"></span>
  </div>
</div>