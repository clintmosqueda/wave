<section class="vision animate-in fade-in">
  <div class="vision-content">
    <span class="vision-dolphin">
      <img src="<?php echo resolve_asset_url('/images/creatures/dolphin-outlined.png')?>" alt="">
    </span>
    <h3 class="vision-heading">our vision</h3>
    <p class="vision-desc">社会と人を繋ぐ。再生回数ではなくて、
    誰が見てくれたのか。温かみが入ってくる。</p>
    <div class="vision-video"></div>
  </div>
</section>