<div class="graphic-works">
  <a class="graphic-works-link" href="<?php echo resolve_archive_url(PENGUIN_POST_TYPE);?>">
    GrApHiC WoRks 
    <span class="graphic-works-icon"></span>
  </a>
  <p class="graphic-works-par">グラフィックの製作実績はこちら</p>
</div>