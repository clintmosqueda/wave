<section class="mv">
  <?php import_part('mv-waves')?>
  <div class="wrapper">
    <div class="mv-content">
      <div class="mv-text rellax" data-rellax-speed="-6">
        <p class="mv-par">他者の痛みに、
        想い馳せる社会へ。</p>
        <span class="mv-by">by <img src="<?php echo resolve_asset_url('/images/logo-top.svg'); ?>" alt=""></span>
      </div>
    </div>
  </div>
</section>