<div class="mv-waves">
  <?php import_part('mv-waves-1', array(
    'modifier' => 'rellax',
    'speed' => '-10',
  ))?>
  <?php import_part('mv-waves-2', array(
    'modifier' => 'rellax',
    'speed' => '-9',
  ))?>
  <?php import_part('mv-waves-3', array(
    'modifier' => 'rellax',
    'speed' => '-8',
  ))?>
  <?php import_part('mv-waves-4', array(
    'modifier' => 'rellax',
    'speed' => '-7',
  ))?>
  <?php import_part('mv-waves-6', array(
    'modifier' => 'rellax',
    'speed' => '-6',
  ))?>
  <?php import_part('mv-waves-7', array(
    'modifier' => 'rellax',
    'speed' => '-5',
  ))?>
  <?php import_part('mv-waves-5', array(
    'modifier' => 'rellax',
    'speed' => '-4',
  ))?>
  <?php import_part('mv-waves-8', array(
    'modifier' => 'rellax',
    'speed' => '-3',
  ))?>
  <?php import_part('mv-waves-9', array(
    'modifier' => 'rellax',
    'speed' => '-2',
  ))?>
  <?php import_part('mv-waves-10', array(
    'modifier' => 'rellax',
    'speed' => '-1',
  ))?>
  <!-- <div class="mv-waves-layer mv-waves-11"><img src="<?php echo resolve_asset_url('/images/waves/mv-wave-11.svg'); ?>" alt="wave"></div> -->
</div>