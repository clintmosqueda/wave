<nav class="nav">
  <a class="nav-link" href="<?php echo resolve_url('about-us'); ?>">waveについて</a>
  <a class="nav-link" href="<?php echo resolve_archive_url(WORKS_POST_TYPE);?>">制作実績</a>
  <a class="nav-link" href="<?php echo resolve_archive_url(NEWS_POST_TYPE);?>">news</a>
  <a class="nav-link" href="<?php echo resolve_url('about-us'); ?>">会社概要</a>
  <a class="nav-link nav-button" href="<?php echo resolve_url('contact'); ?>">お問い合わせ</a>
</nav>