<div class="search">
  <form class="search-form" method="get" id="searchform" action="<?php bloginfo('url'); ?>">
    <div class="search-form-content">
      <input class="search-form-button" type="submit"/>
      <input class="search-form-input" type="text" name="s" id="s" placeholder="例：売却" />
    </div>
  </form>
</div>